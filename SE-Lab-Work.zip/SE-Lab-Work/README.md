# SE Lab Work

This repository contains Software Engineering lab submissions.

## Structure

- `Lab/Lab 1/` – Requirements Engineering and UML Use-Case Modelling
- `Lab/Lab 2/` – Add Lab 2 submission files here
- `Lab/Lab 3/` – Add Lab 3 submission files here
- `Lab/Lab 4/` – Add Lab 4 submission files here
- `Lab/Lab 5/` – Add Lab 5 submission files here
- `Lab/Lab 6/` – Add Lab 6 submission files here
- `Lab/Lab 7/` – Add Lab 7 submission files here

Only files supplied so far have been added. Add the actual work, source code, output evidence, and reports for each remaining lab before final submission.
